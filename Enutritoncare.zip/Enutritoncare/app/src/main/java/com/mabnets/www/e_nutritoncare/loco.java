package com.mabnets.www.e_nutritoncare;

import java.io.Serializable;

public class loco implements Serializable {
    public int id;
    public String location;
}
