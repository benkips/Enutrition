package com.mabnets.www.e_nutritoncare;

import java.io.Serializable;

public class call implements Serializable {
    public String phone;
}
