package com.mabnets.www.e_nutritoncare;

import java.io.Serializable;

public class navigation_details implements Serializable {

    public String username;
}
